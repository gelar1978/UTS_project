data class DataModelItem(
    val NIM: String,
    val Nama: String
)