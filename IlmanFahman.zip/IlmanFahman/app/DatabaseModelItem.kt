data class DatabaseModelItem(
    val NIM: String,
    val Nama: String
)