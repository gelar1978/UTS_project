data class DatabaseItem(
    val NIM: String,
    val Nama: String
)