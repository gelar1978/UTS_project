package com.example.ilmanfahman

import android.content.Context
import android.graphics.Color
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.TextView
import kotlin.random.Random

class GridAdapter(val context: Context, val text: String) : BaseAdapter() {

    val colors = arrayOf(
        Color.RED,
        Color.BLUE,
        Color.GREEN,
        Color.YELLOW,
        Color.CYAN,
        Color.MAGENTA,
        Color.GRAY,
        Color.LTGRAY
    )

    override fun getCount(): Int {
        return text.length
    }

    override fun getItem(position: Int): Any {
        return text[position]
    }

    override fun getItemId(position: Int): Long {
        return position.toLong()
    }

    override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
        val view = convertView ?: LayoutInflater.from(context).inflate(R.layout.grid_item, parent, false)
        val gridText = view.findViewById<TextView>(R.id.gridTextView)
        gridText.text = text[position].toString()

        val gridColor = colors[Random.nextInt(colors.size)]
        view.setBackgroundColor(gridColor)

        return view
    }

}