package com.example.ilmanfahman

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import androidx.recyclerview.widget.RecyclerView.LayoutManager
import com.google.gson.Gson

class MainActivity : AppCompatActivity() {
    private lateinit var recyclerView: RecyclerView

    lateinit var myAdapter: Adapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        recyclerView = findViewById(R.id.recyclerView)

        val jsonData = applicationContext.assets
            .open("database.json").bufferedReader().use {
                it.readText()
            }

        val data = Gson().fromJson(jsonData, Database::class.java)

        myAdapter = Adapter(data)
        myAdapter.onItemClick = {
            val intent = Intent(this, Page1Activity::class.java)
                .putExtra("nama", it.Nama)
                .putExtra("nim", it.NIM)
            startActivity(intent)
        }

        recyclerView.layoutManager = LinearLayoutManager(this)
        recyclerView.adapter = myAdapter
    }

}