package com.example.ilmanfahman

class Database : ArrayList<DatabaseItem>()