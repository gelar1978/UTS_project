package com.example.ilmanfahman

import android.app.Activity
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast

class Page1Activity : AppCompatActivity() {
    private lateinit var mainPageBtn : Button
    private lateinit var nextPageBtn : Button
    private lateinit var showNimNoHp : TextView

    lateinit var inputNim1 : EditText

    companion object {
        private const val REQUEST_CODE = 123
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_page1)

        inputNim1 = findViewById(R.id.inputNim1)
        showNimNoHp = findViewById(R.id.displayNimNoHp)

        mainPageBtn = findViewById(R.id.mainPageBtn)
        nextPageBtn = findViewById(R.id.nextPageBtn1)

        var nama = intent.getStringExtra("nama")
        if (nama == "GLB") {
            nama = "GELAR BUDIMAN" + "/Page-1"
        } else {
            nama = nama + "/Page-1"
        }

        supportActionBar?.title = nama

        mainPageBtn.setOnClickListener { finish() }
        nextPageBtn.setOnClickListener { nextActivity() }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQUEST_CODE && resultCode == Activity.RESULT_OK) {
            val nimNoHp = data?.getStringExtra("nimnohp")
            showNimNoHp.text = nimNoHp
        }
    }

    private fun nextActivity() {
        var nama = intent.getStringExtra("nama")
        var nim = intent.getStringExtra("nim")

        if (inputNim1.text.toString() == nim?.substring(0, 7)) {
            val intent = Intent(this, Page2Activity::class.java)
                .putExtra("nama", nama)
                .putExtra("nim", nim)
            startActivityForResult(intent, REQUEST_CODE)
        } else {
            Toast.makeText(this, inputNim1.text.toString() + " is incorrect!", Toast.LENGTH_SHORT).show()
        }
    }
}