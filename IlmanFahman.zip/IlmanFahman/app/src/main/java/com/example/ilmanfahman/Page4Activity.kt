package com.example.ilmanfahman

import android.app.Activity
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.GridView
import android.widget.TextView

class Page4Activity : AppCompatActivity() {
    private lateinit var previousPageBtn : Button
    private lateinit var showNoHpNim : TextView
    private lateinit var showGrid : GridView

    companion object {
        private const val REQUEST_CODE = 123
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_page4)

        showNoHpNim = findViewById(R.id.displayNimNoHp)
        showGrid = findViewById<GridView>(R.id.displayGrid)
        previousPageBtn = findViewById(R.id.previousPageBtn4)

        var nama = intent.getStringExtra("nama")
        if (nama == "GLB") {
            nama = "GELAR BUDIMAN" + "/Page-4"
        } else {
            nama = nama + "/Page-4"
        }

        var nim = intent.getStringExtra("nim")
        var noHp = intent.getStringExtra("nohp")

        showNoHpNim.text = nim + "/" + noHp

        val gridString = nim + "/" + noHp
        val gridAdapter = GridAdapter(this, gridString)

        showGrid.adapter = gridAdapter
        showGrid.numColumns = 5
        showGrid.columnWidth = GridView.AUTO_FIT

        supportActionBar?.title = nama

        previousPageBtn.setOnClickListener { previousPage() }
    }

    private fun previousPage() {
        var nim = intent.getStringExtra("nim")
        var noHp = intent.getStringExtra("nohp")
        val gridString = nim + "/" + noHp

        val intent = Intent()
            .putExtra("nimnohp", gridString)
        setResult(Activity.RESULT_OK, intent)
        finish()
    }
}