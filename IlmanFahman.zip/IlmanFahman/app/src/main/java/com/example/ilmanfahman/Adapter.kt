package com.example.ilmanfahman

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class Adapter(private var dataList: ArrayList<DatabaseItem>)
    : RecyclerView.Adapter<Adapter.ViewHolder>() {

    var onItemClick : ((DatabaseItem) -> Unit)? = null

    class ViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val dataArea : LinearLayout = view.findViewById(R.id.displayArea)
        val dataNama : TextView = view.findViewById(R.id.displayNama)
        val dataNim : TextView = view.findViewById(R.id.displayNim)
        val circleAvatar : TextView = view.findViewById(R.id.circleAvatar)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) = ViewHolder(
        LayoutInflater.from(parent.context).inflate(R.layout.list_item, parent, false)
    )

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val data = dataList[position]

        holder.dataNama.text = data.Nama
        holder.dataNim.text = data.NIM
        holder.circleAvatar.text = data.Nama[0].toString().uppercase()

        holder.dataArea.setOnClickListener {
            onItemClick?.invoke(data)
        }
    }

    override fun getItemCount(): Int = dataList.size


}