package com.example.ilmanfahman

import android.app.Activity
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.MenuItem
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast

class Page2Activity : AppCompatActivity() {
    private lateinit var previousPageBtn : Button
    private lateinit var nextPageBtn : Button
    private lateinit var alamatEmail : EditText
    private lateinit var noHp : EditText
    private lateinit var digitKe8 : EditText
    private lateinit var showNimNoHp: TextView

    companion object {
        private const val REQUEST_CODE = 123
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_page2)

        alamatEmail = findViewById(R.id.inputEmail)
        noHp = findViewById(R.id.inputNoTelp)
        digitKe8 = findViewById(R.id.inputDigitKe8)
        showNimNoHp = findViewById(R.id.displayNimNoHp)
        previousPageBtn = findViewById(R.id.previousPageBtn2)
        nextPageBtn = findViewById(R.id.nextPageBtn2)

        var nama = intent.getStringExtra("nama")
        if (nama == "GLB") {
            nama = "GELAR BUDIMAN" + "/Page-2"
        } else {
            nama = nama + "/Page-2"
        }

        supportActionBar?.title = nama

        previousPageBtn.setOnClickListener { previousPage() }
        nextPageBtn.setOnClickListener { nextActivity() }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQUEST_CODE && resultCode == Activity.RESULT_OK) {
            val nimNoHp = data?.getStringExtra("nimnohp")
            showNimNoHp.text = nimNoHp
        }
    }

    private fun previousPage() {
        val nimNoHp = showNimNoHp.text

        val intent = Intent()
            .putExtra("nimnohp", nimNoHp)
        setResult(Activity.RESULT_OK, intent)
        finish()
    }

    private fun nextActivity() {
        var nama = intent.getStringExtra("nama")
        var nim = intent.getStringExtra("nim")
        var email = alamatEmail.text.toString()
        var noTelp = noHp.text.toString()

        if (digitKe8.text.toString() == nim?.substring(7, 8)) {
            val intent = Intent(this, Page3Activity::class.java)
                .putExtra("nama", nama)
                .putExtra("nim", nim)
                .putExtra("email", email)
                .putExtra("nohp", noTelp)
            startActivityForResult(intent, REQUEST_CODE)
        } else {
            Toast.makeText(this, digitKe8.text.toString() + " is incorrect",Toast.LENGTH_SHORT).show()
        }
    }
}