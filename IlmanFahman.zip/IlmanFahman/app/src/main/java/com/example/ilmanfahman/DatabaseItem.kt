package com.example.ilmanfahman

import com.google.gson.annotations.SerializedName


data class DatabaseItem(
    @SerializedName("NIM")
    val NIM: String,
    @SerializedName("Nama")
    val Nama: String
)