package com.example.ilmanfahman

import android.app.Activity
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast

class Page3Activity : AppCompatActivity() {
    private lateinit var previousPageBtn : Button
    private lateinit var nextPageBtn : Button
    private lateinit var showEmail : TextView
    private lateinit var showNoHp : TextView
    private lateinit var last2Digit : EditText
    private lateinit var showNimNoHp : TextView
    private lateinit var showProfPict : TextView

    companion object {
        private const val REQUEST_CODE = 123
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_page3)

        showEmail = findViewById(R.id.displayEmail)
        showNoHp = findViewById(R.id.displayNoHp)
        last2Digit = findViewById(R.id.inputDigitKe9_10)
        showNimNoHp = findViewById(R.id.displayNimNoHp)
        showProfPict = findViewById(R.id.profilePict)

        previousPageBtn = findViewById(R.id.previousPageBtn3)
        nextPageBtn = findViewById(R.id.nextPageBtn3)

        var nama = intent.getStringExtra("nama")
        if (nama == "GLB") {
            nama = "GELAR BUDIMAN" + "/Page-3"
        } else {
            nama = nama + "/Page-3"
        }

        supportActionBar?.title = nama

        showProfPict.text = nama[0].toString().uppercase()

        var email = intent.getStringExtra("email")
        showEmail.text = email

        var noHp = intent.getStringExtra("nohp")
        showNoHp.text = noHp



        previousPageBtn.setOnClickListener { previousPage() }
        nextPageBtn.setOnClickListener { nextActivity() }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQUEST_CODE && resultCode == Activity.RESULT_OK) {
            val nimNoHp = data?.getStringExtra("nimnohp")
            showNimNoHp.text = nimNoHp
        }
    }

    private fun previousPage() {
        val nimNoHp = showNimNoHp.text

        val intent = Intent()
            .putExtra("nimnohp", nimNoHp)
        setResult(Activity.RESULT_OK, intent)
        finish()
    }

    private fun nextActivity() {
        var nama = intent.getStringExtra("nama")
        var nim = intent.getStringExtra("nim")
        var email = intent.getStringExtra("email")
        var noHp = intent.getStringExtra("nohp")

        if (last2Digit.text.toString() == nim?.substring(8,10)) {
            val intent = Intent(this, Page4Activity::class.java)
                .putExtra("nama", nama)
                .putExtra("nim", nim)
                .putExtra("email", email)
                .putExtra("nohp", noHp)
            startActivityForResult(intent, REQUEST_CODE)
        } else {
            Toast.makeText(this, last2Digit.text.toString() + " is incorrect", Toast.LENGTH_SHORT).show()
        }
    }
}